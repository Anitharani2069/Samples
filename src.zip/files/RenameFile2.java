package files;
import java.io.File;

public class RenameFile2 {
	   public static void main(String[] args) { 
	      File oldfile = new File("C://users//nyennama//Documents//java.txt");
	      File newfile = new File("C://users//nyennama//Documents//vijay.txt");

	      if(oldfile.renameTo(newfile)) {
	         System.out.println("File name changed succesful");
	      } else {
	         System.out.println("Rename failed");
	      } 
	   }
	}
