package files;
import java.io.File;

public class FileExist {
	
	
	   public static void main(String[] args) {
	      File file = new File("C://Users//nyennama//java.txt");
	      System.out.println(file.exists());
	   }
	}