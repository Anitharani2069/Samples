package files;
import java.io.File;
import java.io.IOException;

public class CreateFile 
{
   public static void main(String[] args) throws Exception {
      try {
         File file = new File("myfile.txt");
         
         if(file.createNewFile())System.out.println("Success!");
         else System.out.println ("Error, file already exists.");
      }
      catch(IOException ioe) {
         ioe.printStackTrace();
      }
   }
}