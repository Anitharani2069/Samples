package files;
import java.io.File;
 
public class FileReadOnly {
	  public static void main(String[] args) {
	      File file = new File("C://users//nyennama//documents");
	      System.out.println(file.setReadOnly());
	      System.out.println(file.canWrite());
	   }
	}