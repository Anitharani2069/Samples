package files;
import java.io.File;
public class CreateFileInSpecifiedDirectory {
	
	   public static void main(String[] args) throws Exception {
	      File file = null;
	      File dir = new File("C:\\Users\\nyennama\\Documents");
	      file = File.createTempFile("JavaTemp", ".javatemp", dir);
	      System.out.println(file.getPath());
	   }
	}