package files;
import java.io.File;
import java.io.IOException;

public class FileReadOnly2 {
	  public static void main(String[] args) throws IOException { 
	      File file = new File("c:/file.txt");
	      file.setReadOnly();
	   
	      if(file.canWrite()) {
	         System.out.println("This file is writable");
	      } else {
	         System.out.println("This file is read only"); 
	      } 
	      file.setWritable(true);
	      if(file.canWrite()) {
	         System.out.println("This file is writable");
	      } else {
	         System.out.println("This file is read only");
	      }
	   }
	}