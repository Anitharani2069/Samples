package ui;

import java.util.Collection;
import java.util.Scanner;

import bean.Account;
import exception.AccountNotFoundException;
import exception.InSufficientBalanceException;
import service.AccountService;
import service.AccountServiceImpl;

public class Main_AccountService {
	static Scanner sc = new Scanner(System.in);

	public static Account getInputAccount() {
		String accountName = getInput("Enter AccountName:");
		double openingBalance = Double.parseDouble(getInput("Enter Opening Balance:"));
		Account account = new Account(accountName, openingBalance);
		return account;
	}

	public static String getInput(String message) {
		System.out.println(message);
		return sc.next();
	}

	public static void main(String[] args) {
		AccountService accountService = new AccountServiceImpl(5);
		int choice = 0;
		int accountNo, accountNoFrom, accountNoTo;
		double amount;
		Account account;
		do {
			System.out.println("Welcome to World Bank...");
			System.out.println("1.Create Account");
			System.out.println("2.Deposit");
			System.out.println("3.Withdraw");
			System.out.println("4.FundsTransfer");
			System.out.println("5.Show Balance");
			System.out.println("6.Print Transactions");
			System.out.println("7.Exit");
			System.out.print("Enter Choice:");
			choice = sc.nextInt();

			switch (choice) {
			// 1.Create Account
			case 1:
				System.out.println("\t::==>Account Creation -> STARTED...");
				account = getInputAccount();
				account = accountService.createAccount(account);
				//System.out.println(account);
				System.out.println("\t::==>Account Creation -> ENDED...");
				break;
			// 2.Deposit
			case 2:
				System.out.println("\t::==>Account Deposit -> STARTED...");
				accountNo = Integer.parseInt(getInput("\nEnter Account No: "));
				amount = Double.parseDouble(getInput("\nEnter Amount: "));
				try {
					accountService.deposit(accountNo, amount);
					System.out.println("\t::==>Account Deposit -> ENDED...");
				} catch (AccountNotFoundException e) {
					System.err.println("Account Deposit:->"+e.getMessage());
				}
				break;
			// 3.Withdraw
			case 3:
				System.out.println("\t::==>Account Withdraw -> STARTED...");
				accountNo = Integer.parseInt(getInput("\nEnter Account No: "));
				amount = Double.parseDouble(getInput("\nEnter Amount: "));
				try {
					accountService.withdraw(accountNo, amount);
					System.out.println("\t::==>Account Withdraw -> ENDED...");
				} catch (AccountNotFoundException e) {
					System.err.println("Account Withdraw:->"+e.getMessage());
				} catch (InSufficientBalanceException e) {
					System.err.println("Account Withdraw:->"+e.getMessage());
				}
				break;
			// 4.FundsTransfer
			case 4:
				System.out.println("\t::==>Account Balance Transfer -> STARTED...");
				accountNoTo = Integer.parseInt(getInput("\nEnter From Account No: "));
				accountNoFrom = Integer.parseInt(getInput("\nEnter To Account No: "));
				amount = Double.parseDouble(getInput("\nEnter Amount: "));
				try {
					accountService.fundsTransfer(accountNoFrom, accountNoTo, amount);
					System.out.println("\t::==>Account Balance Transfer -> ENDED...");
				} catch (AccountNotFoundException e) {
					System.err.println("Account Withdraw:->"+e.getMessage());
				} catch (InSufficientBalanceException e) {
					System.err.println("Account Withdraw:->"+e.getMessage());
				}
				break;
			// 5.Show Balance
			case 5:
				System.out.println("\t::==>Account Show Balance -> STARTED...");
				accountNo = Integer.parseInt(getInput("\nEnter From Account No: "));
				try {
					amount = accountService.getBalance(accountNo);
					System.out.println("Current Balance: " + amount);
					System.out.println("\t::==>Account Show Balance -> ENDED...");
				} catch (AccountNotFoundException e) {
					System.err.println("Account Show Balance:->"+e.getMessage());
				}
				break;
			// 6.Print Transactions
			case 6:
				System.out.println("\t::==>Account Balance Transfer -> STARTED...");
				Collection<Account> accounts = accountService.getTransactions();
				accounts.forEach(System.out::println);
				System.out.println("\t::==>Account Balance Transfer -> ENDED...");
				break;
			default:
				System.out.println("Exit...");
			}
		} while (choice != 7);
	}
	
}
