package strings;
//import java.security.KeyStore.Entry;
import java.util.*;

public class Maap {

     public static void main(String[] args) {

         HashMap <String,String> hmap = new HashMap<String,String>();
         List<String>list=new ArrayList<String>();
         System.out.println("How many employees you want to add?");
         Scanner in = new Scanner(System.in);
         int n=in.nextInt();
         System.out.println("Add " + n + " employees");
         String b,a;
         for(int i=0;i<n;i++){
              a=in.next();
              b=in.next();

             hmap.put(a,b);
         }
         Set set=hmap.keySet();
         Iterator<String> itr=set.iterator();
         System.out.println("Enter organization name");
         String b1=in.next();
        
         for(Map.Entry<String, String> entry:hmap.entrySet())
         {
        	 if(entry.getValue().equals(b1))
        	 {
        		 System.out.println(entry.getKey());
        	 }
         }
        }
     }
