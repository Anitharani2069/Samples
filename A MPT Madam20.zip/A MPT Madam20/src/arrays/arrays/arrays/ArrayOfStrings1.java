package arrays.arrays.arrays;

import java.util.Arrays;

public class ArrayOfStrings1 {

	   public static void main(String[] args) {
	      String[] arr = new String[] {"Tutorials", "Point", ".com"}; 
	      System.out.println(Arrays.toString(arr));
	   }
	}
