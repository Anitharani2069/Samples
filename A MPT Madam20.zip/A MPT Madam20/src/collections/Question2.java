package collections;
public class Question2 implements Comparable<Question2>{
	private int customerId;
	private String customerName;
	private String customerAddress;
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress() {
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}
	public Question2(int customerId, String customerName, String customerAddress) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerAddress = customerAddress;
	}
	@Override
	public String toString() {
		return "Question1 [customerId=" + customerId + ", customerName=" + customerName + ", customerAddress="
				+ customerAddress + "]";
	}
	@Override
	public int compareTo(Question2 c1) {
		 if(this.customerId==c1.customerId)
	            return 0;
	        else if(this.customerId>c1.customerId)
	            return 1;
	        else
	        return -1;
		 
		 
	}
	
}
