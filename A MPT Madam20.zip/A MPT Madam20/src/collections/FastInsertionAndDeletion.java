package collections;
import java.util.LinkedList;
import java.util.List;

public class FastInsertionAndDeletion {
	public static void main(String args[])
	{
		List<Question1> list=new LinkedList<Question1>();
		Question1 obj=new Question1(5,"supriya","Ichalkaranji");
		Question1 obj1=new Question1(1,"snehal","Koprochi");
		Question1 obj2=new Question1(2,"priti","sangli");
		Question1 obj3=new Question1(6,"jyotiii","sangli");
		Question1 obj4=new Question1(3,"snehalii","Koporochi");
		Question1 obj5=new Question1(4,"snehaol","Koprochoi");

		list.add(obj);
		list.add(obj1);
		list.add(obj2);
		list.add(obj3);
		list.add(obj4);
		//list.add(obj5);
		
		System.out.println(list);
		list.add(5, obj5);
		System.out.println(list);
		System.out.println(list.get(3));
		//System.out.println(list);

	}

}
