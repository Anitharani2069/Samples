package collections;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class IteratingThroughCollection {
	public static void main(String args[])
	{

		Set<Question1> set=new TreeSet<Question1>();
		Question1 obj=new Question1(5,"supriya","Ichalkaranji");
		Question1 obj1=new Question1(1,"snehal","Koprochi");
		Question1 obj2=new Question1(2,"priti","sangli");
		set.add(obj);
		set.add(obj1);
		set.add(obj2);
		List<Question1> list=new ArrayList<>(set);
		Iterator itr=set.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		Scanner sc=new Scanner(System.in);
		int id=sc.nextInt();
		
		for(int i=0;i<list.size();i++)
		{
			Question1 question1=list.get(i);
			if(question1.getCustomerId()==id)
			{
				list.remove(question1);
			}
		}
		
		Iterator itr1=list.iterator();
		
		while(itr1.hasNext())
		{
			System.out.println(itr1.next());

		}
	}
}
