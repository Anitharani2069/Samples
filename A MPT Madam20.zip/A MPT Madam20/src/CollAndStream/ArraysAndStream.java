package CollAndStream;
import java.util.Arrays;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class ArraysAndStream {

	public static void main(String[] args) {

			int arr[]={10,20,60,48,90,70};
			IntStream stream=Arrays.stream(arr);
			IntStream stream1=stream.filter(i->i>50);
			//stream1.forEach(System.out::println);

			IntStream stream2=stream1.map(i->i+5);
			//stream2.forEach(System.out::println);
			//stream2.
			System.out.println(stream2.sum());

	}

}
