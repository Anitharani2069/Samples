package CollAndStream;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class CollectionAndStream2 {

	public static void main(String[] args) {
		List<CollectionAndStream1> list=new ArrayList<CollectionAndStream1>();
		CollectionAndStream1 obj=new CollectionAndStream1("supriya",Gender.FEMALE);
		CollectionAndStream1 obj1=new CollectionAndStream1("dhjf",Gender.MALE);
		CollectionAndStream1 obj2=new CollectionAndStream1("iotuo",Gender.FEMALE);
		CollectionAndStream1 obj3=new CollectionAndStream1("gyuit",Gender.MALE);
		list.add(obj);
		list.add(obj1);
		list.add(obj2);
		list.add(obj3);
		
		Stream<CollectionAndStream1> stream=list.stream();
		Stream<CollectionAndStream1>stream1=stream.filter((CollectionAndStream1)->CollectionAndStream1.getGender().equals(Gender.FEMALE));
		List<CollectionAndStream1>list1=stream1.collect(Collectors.toList());
		
		list1.forEach(System.out::println);
		//System.out.println(list);

	}

}
