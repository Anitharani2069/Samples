package fileIo;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class WriteDataToFileFromUser {
	public static void main(String args[]) throws IOException
	{
	Scanner scanner=new Scanner(System.in);
		System.out.println("Enter mobile number:");
		String mobileNo=scanner.next();
		System.out.println("Enter name:");
		String name=scanner.next();
		System.out.println("Enter city:");
		String city=scanner.next();
		FileWriter fileWriter=new FileWriter(new File("f.txt"));
		fileWriter.write(mobileNo);
		
		/*System.out.println(" ");

		fileWriter.write(name);
		System.out.println(" ");

		fileWriter.write(city);
		fileWriter.close();
		
		FileReader fileReader=new FileReader(new File("f.txt"));
		BufferedReader bufferedReader=new BufferedReader(fileReader);
		int i;
		while((i=bufferedReader.read())!=-1)
		{
			System.out.println(i);
		}
		*/
		FileWriter fw = new
                FileWriter("f.txt");
        BufferedWriter writeFileBuffer = new BufferedWriter(fw);
        writeFileBuffer.write(mobileNo);
        writeFileBuffer.write(name);
        writeFileBuffer.write(city);
        writeFileBuffer.close();
        FileReader fileReader=new FileReader(new File("f.txt"));
		BufferedReader bufferedReader=new BufferedReader(fileReader);
		System.out.println("Enter mobile number");
		String number=scanner.next();
		int i;
		while((i=bufferedReader.read())!=-1)
		{
			if(number.equals(mobileNo))
			{
				System.out.println(bufferedReader.readLine());
			}
		}
		//BufferedReader reader =new BufferedReader(new InputStreamReader(System.in)); 
      
     // Reading data using readLine 
     //String name1 = reader.readLine(); 
		
	}

}
