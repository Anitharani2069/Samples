package fileIo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class ReadAndWriteInFile {

	public static void main(String[] args)  {
		
		//ReadAndWriteInFile rw=new ReadAndWriteInFile();
		Customer question1=new Customer(10, "dch", "jhhgbcsd");
		Customer question2=new Customer(20, "dchbv", "yhgbcsd");
		Customer question3=new Customer(30, "dchghb", "yjhgbcsd");
		Customer question4=new Customer(40, "dchyh", "klhgbcsd");
		try{
			File file=new File("new.txt");
		FileOutputStream fr=new FileOutputStream(file);
		ObjectOutputStream fo=new ObjectOutputStream(fr);
		fo.writeObject(question1);
		fo.writeObject(question2);
		fo.writeObject(question3);
		fo.writeObject(question4);

		fr.close();
		fo.close();
		FileInputStream fi=new FileInputStream(file);
		ObjectInputStream oi=new ObjectInputStream(fi);
		Customer c1=(Customer) oi.readObject();
		Customer c2=(Customer) oi.readObject();
		Customer c3=(Customer) oi.readObject();
		Customer c4=(Customer) oi.readObject();

		System.out.println(c1.toString());
		System.out.println(c2.toString());
		System.out.println(c3.toString());
		System.out.println(c4.toString());

		fi.close();
		oi.close();
				//System.out.println("complete");
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		
	

	

}


