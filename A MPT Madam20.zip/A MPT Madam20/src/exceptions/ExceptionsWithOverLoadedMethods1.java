package exceptions;

 

	class NewClass1 { 
		   void msg()throws Exception{System.out.println("this is parent");}
		}
	public class ExceptionsWithOverLoadedMethods1 extends NewClass1 {
		ExceptionsWithOverLoadedMethods1() {
		   }
		   void msg()throws ArithmeticException{System.out.println("This is child");}
		   public static void main(String args[]) {
		      NewClass1 n = new ExceptionsWithOverLoadedMethods1();
		      try {
		         n.msg();
		      } catch(Exception e){}
		   }  
		}