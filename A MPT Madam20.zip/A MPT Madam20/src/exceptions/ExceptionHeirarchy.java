package exceptions;


	class Animal extends Exception {
	}
	class Mammel extends Animal {
	}
	public class ExceptionHeirarchy {
	   public static void main(String[] args) {
	      try {
	         throw new Mammel();
	      } catch (Mammel m) {
	         System.err.println("It is mammel");
	      }
	   }
	}