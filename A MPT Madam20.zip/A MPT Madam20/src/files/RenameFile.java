package files;
import java.io.File;

public class RenameFile {
	   public static void main(String[] args) {
	      File oldName = new File("C://users//nyennama//Documents//vijay.txt");
	      File newName = new File("C://users//nyennama//Documents//java.txt");
	      
	      if(oldName.renameTo(newName)) {
	         System.out.println("renamed");
	      } else {
	         System.out.println("Error");
	      }
	   }
	}
