package files;
import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class CreateFileInSpecifiedDirectory2 {
	
	   public static void main(String[] args) throws IOException {
	      Path p1 = Paths.get("C:\\Users\\nyennama\\Downloads.txt");
	      Files.createDirectories(p1.getParent());
	      try {
	         Files.createFile(p1);
	      } catch (FileAlreadyExistsException e) {
	         System.err.println("already exists: " + e.getMessage());
	      }
	   }
	}