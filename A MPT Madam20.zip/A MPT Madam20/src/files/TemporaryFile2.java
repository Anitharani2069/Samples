package files;
import java.io.File;
import java.io.IOException;

public class TemporaryFile2 {
	   public static void main(String[] args) { 
	      try { 
	         File f1 = File.createTempFile("temp-file-name", ".tmp");
	    	   System.out.println("Temp file : " + f1.getAbsolutePath());
	      } catch(IOException e) { 
	         e.printStackTrace();
	      } 
	   }
	}