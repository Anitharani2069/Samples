package files;

import java.io.*;

public class FileWrite {
	   public static void main(String[] args) {
	      try {
	         BufferedWriter out = new BufferedWriter(new FileWriter("outfilename"));
	         out.write("aString");
	         out.close();
	         System.out.println("File created successfully");
	      }
	      catch (IOException e) {
	      }
	   }
	}