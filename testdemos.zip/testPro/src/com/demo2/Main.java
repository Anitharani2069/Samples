package com.demo2;

/**
 * 
 * @author spavanku
 * 
 * accept string as an input from the user, and return the output as string by replacing 
 * the each and every character with next character of the given input.
 * 
 *  sample Input 1:
 *  =============
 *  capgemini
 *  
 *  Sample output 1:
 *  ==============
 *  dbqfnjoj
 * 
 * 	sample Input 2:
 *  ===============
 *  apple
 * 
 *  Sample output 2:
 *  ==============
 *  bqqmf
 *  
 */
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public static String getString(String organization) {
		
		return null;

	}


}
