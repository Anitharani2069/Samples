package com.demo3;

import java.util.List;

/**
 * 
 * @author spavanku
 *
 *	take List of Strings as input, and return the string which is having max length as an output.
 *
 *	Input1:
 *	======
 *	How many names you want to add:
 *	4
 *	pavan
 *	kumar
 *	siva
 *	sudheer
 *
 * Output1:
 * ========
 * sudheer
 *
 */

public class Main {

	public static void main(String[] args) {

		// your logic here
	}

	public static String getnames(List<String> names) {

		return null;
	}

}
