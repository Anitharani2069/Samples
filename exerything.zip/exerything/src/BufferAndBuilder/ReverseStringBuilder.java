package BufferAndBuilder;
public class ReverseStringBuilder {
 
          public static void main(String args[]) {
 
                 StringBuilder sBui = new StringBuilder("Reversed");
 
                
 
                 System.out.println("Before reverse method: " +sBui);
 
                
 
                 //Using reverse() method
 
                 sBui.reverse();
 
                 System.out.println("After reverse() method: " +sBui);
 
     }
 
 
 
}