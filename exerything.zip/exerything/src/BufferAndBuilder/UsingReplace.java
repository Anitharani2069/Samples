package BufferAndBuilder;
public class UsingReplace {
 
          public static void main(String args[]) {
 
                 StringBuilder sBui = new StringBuilder("Hello mutable string by Java. ");
 
                
 
                 System.out.println("Before Replace: " +sBui);
 
                
 
                 //Using replace method
 
                 sBui.replace(6,30,"World!");
 
                 System.out.println("After replace() method: " +sBui);
 
     }
 
 
 
}