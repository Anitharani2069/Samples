package BufferAndBuilder;
public class UsingLastIndexOf
{
public static void main(String args[]) {
 
                
 
                 StringBuilder sbindOf = new StringBuilder("Java is high level language! Java is cool. Java is Awesome.");
 
                    int x;
 
                    int y;
 
 
 
                    //Using indexOf method for substring
 
                     x = sbindOf.lastIndexOf("Java");
 
                     y = sbindOf.lastIndexOf("Java", 40);
 
                 
 
                     System.out.println("The lastIndexOf 'Java' from right most: " + x +"\n");
 
                     System.out.println("The lastIndexOf of 'Java' from index 40: " +y);
 
 
 
        }
 
}