package examplesFileHandling;
import java.io.*;
import java.util.Date;

public class GetTheLastModificationDateAndTimeOfFile 
{
	public static void main(String[] args)

	{
		// Enter the file name here.
		File file = new File("E:/IncludeHelp.txt");

		// lastModified is the predefined function of date class in java.
		long lastModified = file.lastModified();

		// will print when the file last modified.
		System.out.println("File was last modified at : " + new Date(lastModified));
	}
}