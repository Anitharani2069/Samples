package examplesFileHandling;
import java.io.*;

public class SizeOfFile 
{
	public static void main(String[] args) 
	{
		//create file object.
		// enter the file name.
		File file = new File("E:/includehelp.txt");

		// calculate the size of the file.
		long fileSize = file.length();

		// return the file size in bytes,KB and MB.
		System.out.println("File size in bytes is : " + fileSize);
		System.out.println("File size in KB is : " + (double)fileSize/1024);
		System.out.println("File size in MB is : " + (double)fileSize/(1024*1024));
	}
}