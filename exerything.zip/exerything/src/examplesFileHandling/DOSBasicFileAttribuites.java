package examplesFileHandling;
import java.nio.file.*;
import java.nio.file.attribute.*;
import java.util.Scanner;

public class DOSBasicFileAttribuites
{
    public static void main(String[] args) throws Exception 
    {
    	// create object of scanner.
    	Scanner KB=new Scanner(System.in);
    				 
    	// enter path here.
    	System.out.print("Enter the file path : ");
    	String A=KB.next();
        Path path = FileSystems.getDefault().getPath(A);
        
        // create object of dos attribute.
        DosFileAttributeView view = Files.getFileAttributeView(path,DosFileAttributeView.class);
        
        // this function read the attribute of dos file.
        DosFileAttributes attributes = view.readAttributes();

        System.out.println("isArchive: " + attributes.isArchive());
        System.out.println("isHidden: " + attributes.isHidden());
        System.out.println("isReadOnly: " + attributes.isReadOnly());
        System.out.println("isSystem: " + attributes.isSystem());
    }
}