/*IntStream infiniteNumberStream = IntStream.iterate(1, i -> i+1);
         
int[] intArray = infiniteNumberStream.limit(10)
                            .toArray();
 
System.out.println(Arrays.toString(intArray));*/ 