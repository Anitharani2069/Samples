/*List<Integer> ints = IntStream.iterate(0, i -> i + 2)
                        .mapToObj(Integer::valueOf)
                        .limit(10)
                        .collect(Collectors.toList());
 
System.out.println(ints);*/