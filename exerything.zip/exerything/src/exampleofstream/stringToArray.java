/*Stream<String> tokenStream = Arrays.asList("A", "B", "C", "D").stream();  //stream
         
String[] tokenArray = tokenStream.toArray(String[]::new);   //array
 
System.out.println(Arrays.toString(tokenArray));*/   