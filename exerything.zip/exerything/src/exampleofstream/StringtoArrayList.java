package exampleofstream;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;
 
public class StringtoArrayList
{
    public static void main(String[] args)
    {  
        Stream<String> tokenStream = Stream.of("A", "B", "C", "D");   //stream
         
        List<String> tokenlist = tokenStream.collect(Collectors.toList());    //list
 
        System.out.println(tokenlist); 
    }
}