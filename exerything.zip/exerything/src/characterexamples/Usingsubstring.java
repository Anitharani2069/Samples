package characterexamples;
class C5{
  public static void main(String[] args){
    String s1 = "Umbrella";
    String s2 = s1.substring(2);
    String s3 = s1.substring(2,6);
    System.out.println(s2);
    System.out.println(s3);
  }
}