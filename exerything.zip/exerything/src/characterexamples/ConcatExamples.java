package characterexamples;
class C7{
  public static void main(String[] args){
    String s1 = "Codes";
    s1 = s1.concat("Dope");
    System.out.println(s1);
  }
}