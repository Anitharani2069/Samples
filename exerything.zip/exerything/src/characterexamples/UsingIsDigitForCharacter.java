package characterexamples;
public class UsingIsDigitForCharacter 
{ 
    public static void main(String[] args) 
    { 
        // print false as A is character 
        System.out.println(Character.isDigit('A'));  
          
        System.out.println(Character.isDigit('0'));  
          
    } 
} 