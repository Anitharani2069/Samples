package characterexamples;
class C3{
  public static void main(String[] args){
    String s1 = "Hello";
    char ch = s1.charAt(2);
    System.out.println(ch);
  }
}